CREATE VIEW `LabeledLobbyist` AS
  SELECT DISTINCT
    `p`.`pid`    AS `pid`,
    `p`.`first`  AS `first`,
    `p`.`middle` AS `middle`,
    `p`.`last`   AS `last`,
    'Lobbyist'   AS `PersonType`,
    `l`.`state`  AS `state`
  FROM (`DDDB2016Aug`.`Person` `p`
    JOIN `DDDB2016Aug`.`Lobbyist` `l` ON ((`p`.`pid` = `l`.`pid`)))