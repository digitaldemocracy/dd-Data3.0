CREATE VIEW `FrequentDonors` AS
  (SELECT
     `DDDB2016Aug`.`Contribution`.`donorOrg` AS `donorOrg`,
     count(0)                                AS `foo`
   FROM `DDDB2016Aug`.`Contribution`
   GROUP BY `DDDB2016Aug`.`Contribution`.`donorOrg`
   ORDER BY `foo` DESC
   LIMIT 50)