CREATE VIEW `SplitTerm` AS
  SELECT
    `t1`.`pid`         AS `pid`,
    `t1`.`year`        AS `session_year`,
    year(`t1`.`start`) AS `specific_year`
  FROM `DDDB2016Aug`.`Term` `t1`
  UNION SELECT
          `t2`.`pid`                                AS `pid`,
          `t2`.`year`                               AS `session_year`,
          ifnull(year(`t2`.`end`), year(curdate())) AS `specific_year`
        FROM `DDDB2016Aug`.`Term` `t2`