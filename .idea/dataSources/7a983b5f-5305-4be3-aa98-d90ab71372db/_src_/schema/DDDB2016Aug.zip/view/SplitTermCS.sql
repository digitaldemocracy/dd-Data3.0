CREATE VIEW `SplitTermCS` AS
  SELECT
    `t1`.`pid`              AS `pid`,
    `t1`.`session_year`     AS `session_year`,
    year(`t1`.`start_date`) AS `specific_year`
  FROM `DDDB2016Aug`.`ConsultantServesOn` `t1`
  UNION SELECT
          `t2`.`pid`                                     AS `pid`,
          `t2`.`session_year`                            AS `session_year`,
          ifnull(year(`t2`.`end_date`), year(curdate())) AS `specific_year`
        FROM `DDDB2016Aug`.`ConsultantServesOn` `t2`