CREATE VIEW `LabeledLegStaff` AS
  SELECT
    `p`.`pid`           AS `pid`,
    `p`.`first`         AS `first`,
    `p`.`middle`        AS `middle`,
    `p`.`last`          AS `last`,
    'Legislative Staff' AS `PersonType`,
    `sa`.`state`        AS `state`
  FROM (`DDDB2016Aug`.`Person` `p`
    JOIN `DDDB2016Aug`.`LegislativeStaff` `sa` ON ((`p`.`pid` = `sa`.`pid`)))