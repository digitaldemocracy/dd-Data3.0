CREATE VIEW `FormerLegs` AS
  SELECT
    `DDDB2016Aug`.`PersonClassifications`.`pid`             AS `pid`,
    `DDDB2016Aug`.`PersonClassifications`.`state`           AS `state`,
    sum(`DDDB2016Aug`.`PersonClassifications`.`is_current`) AS `sum(is_current)`
  FROM `DDDB2016Aug`.`PersonClassifications`
  WHERE (`DDDB2016Aug`.`PersonClassifications`.`PersonType` = 'Legislator')
  GROUP BY `DDDB2016Aug`.`PersonClassifications`.`pid`, `DDDB2016Aug`.`PersonClassifications`.`state`
  HAVING (sum(`DDDB2016Aug`.`PersonClassifications`.`is_current`) = 0)