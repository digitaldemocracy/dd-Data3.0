CREATE VIEW `LabeledLeg` AS
  SELECT
    `p`.`pid`    AS `pid`,
    `p`.`first`  AS `first`,
    `p`.`middle` AS `middle`,
    `p`.`last`   AS `last`,
    'Legislator' AS `PersonType`,
    `l`.`state`  AS `state`
  FROM (`DDDB2016Aug`.`Person` `p`
    JOIN `DDDB2016Aug`.`Legislator` `l` ON ((`p`.`pid` = `l`.`pid`)))