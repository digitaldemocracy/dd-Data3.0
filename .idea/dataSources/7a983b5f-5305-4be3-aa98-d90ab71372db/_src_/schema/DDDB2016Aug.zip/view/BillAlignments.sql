CREATE VIEW `BillAlignments` AS
  SELECT
    max(`u`.`uid`)  AS `uid`,
    `l`.`pid`       AS `pid`,
    `u`.`alignment` AS `alignment`,
    `u`.`did`       AS `did`
  FROM (`DDDB2016Aug`.`Lobbyist` `l`
    JOIN `DDDB2016Aug`.`currentUtterance` `u` ON ((`l`.`pid` = `u`.`pid`)))
  WHERE (`u`.`did` IS NOT NULL)
  GROUP BY `l`.`pid`, `u`.`alignment`, `u`.`did`