CREATE VIEW `LobTerms` AS
  SELECT
    `le`.`pid`                                                              AS `pid`,
    `nr`.`SeqValue`                                                         AS `specific_year`,
    if(((`nr`.`SeqValue` % 2) = 1), `nr`.`SeqValue`, (`nr`.`SeqValue` - 1)) AS `session_year`
  FROM (`DDDB2016Aug`.`LobbyistEmployment` `le`
    JOIN `DDDB2016Aug`.`NumRange` `nr`
      ON (((`le`.`ls_beg_yr` <= `nr`.`SeqValue`) AND (`le`.`ls_end_yr` >= `nr`.`SeqValue`))))
  UNION SELECT
          `lde`.`pid`                                                             AS `pid`,
          `nr`.`SeqValue`                                                         AS `specific_year`,
          if(((`nr`.`SeqValue` % 2) = 1), `nr`.`SeqValue`, (`nr`.`SeqValue` - 1)) AS `session_year`
        FROM (`DDDB2016Aug`.`LobbyistDirectEmployment` `lde`
          JOIN `DDDB2016Aug`.`NumRange` `nr`
            ON (((`lde`.`ls_beg_yr` <= `nr`.`SeqValue`) AND (`lde`.`ls_end_yr` >= `nr`.`SeqValue`))))
  UNION SELECT
          `lr`.`pid`                                                                 AS `pid`,
          year(`h`.`date`)                                                           AS `specific_year`,
          if(((year(`h`.`date`) % 2) = 1), year(`h`.`date`), (year(`h`.`date`) - 1)) AS `session_year`
        FROM (`DDDB2016Aug`.`LobbyistRepresentation` `lr`
          JOIN `DDDB2016Aug`.`Hearing` `h` ON ((`lr`.`hid` = `h`.`hid`)))