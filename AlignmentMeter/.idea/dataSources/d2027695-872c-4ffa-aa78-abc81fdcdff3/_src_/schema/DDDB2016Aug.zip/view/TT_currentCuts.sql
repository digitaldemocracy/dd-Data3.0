CREATE VIEW `TT_currentCuts` AS
  SELECT
    `DDDB2016Aug`.`TT_Cuts`.`cutId`           AS `cutId`,
    `DDDB2016Aug`.`TT_Cuts`.`videoId`         AS `videoId`,
    `DDDB2016Aug`.`TT_Cuts`.`fileId`          AS `fileId`,
    `DDDB2016Aug`.`TT_Cuts`.`fileName`        AS `fileName`,
    `DDDB2016Aug`.`TT_Cuts`.`start_time`      AS `start_time`,
    `DDDB2016Aug`.`TT_Cuts`.`end_time`        AS `end_time`,
    `DDDB2016Aug`.`TT_Cuts`.`leading_silence` AS `leading_silence`,
    `DDDB2016Aug`.`TT_Cuts`.`type`            AS `type`,
    `DDDB2016Aug`.`TT_Cuts`.`finalized`       AS `finalized`,
    `DDDB2016Aug`.`TT_Cuts`.`current`         AS `current`,
    `DDDB2016Aug`.`TT_Cuts`.`created`         AS `created`,
    `DDDB2016Aug`.`TT_Cuts`.`lastTouched`     AS `lastTouched`,
    `DDDB2016Aug`.`TT_Cuts`.`parent`          AS `parent`,
    `DDDB2016Aug`.`TT_Cuts`.`lastTouched_ts`  AS `lastTouched_ts`
  FROM `DDDB2016Aug`.`TT_Cuts`
  WHERE (`DDDB2016Aug`.`TT_Cuts`.`current` = TRUE)
  ORDER BY `DDDB2016Aug`.`TT_Cuts`.`videoId` DESC, `DDDB2016Aug`.`TT_Cuts`.`cutId`