CREATE VIEW `currentUtterance` AS
  SELECT
    `DDDB2016Aug`.`Utterance`.`uid`            AS `uid`,
    `DDDB2016Aug`.`Utterance`.`vid`            AS `vid`,
    `DDDB2016Aug`.`Utterance`.`pid`            AS `pid`,
    `DDDB2016Aug`.`Utterance`.`time`           AS `time`,
    `DDDB2016Aug`.`Utterance`.`endTime`        AS `endTime`,
    `DDDB2016Aug`.`Utterance`.`text`           AS `text`,
    `DDDB2016Aug`.`Utterance`.`type`           AS `type`,
    `DDDB2016Aug`.`Utterance`.`alignment`      AS `alignment`,
    `DDDB2016Aug`.`Utterance`.`state`          AS `state`,
    `DDDB2016Aug`.`Utterance`.`did`            AS `did`,
    `DDDB2016Aug`.`Utterance`.`lastTouched`    AS `lastTouched`,
    `DDDB2016Aug`.`Utterance`.`lastTouched_ts` AS `lastTouched_ts`,
    `DDDB2016Aug`.`Utterance`.`dr_changed`     AS `dr_changed`,
    `DDDB2016Aug`.`Utterance`.`dr_changed_ts`  AS `dr_changed_ts`
  FROM `DDDB2016Aug`.`Utterance`
  WHERE ((`DDDB2016Aug`.`Utterance`.`current` = TRUE) AND (`DDDB2016Aug`.`Utterance`.`finalized` = TRUE))
  ORDER BY `DDDB2016Aug`.`Utterance`.`time` DESC